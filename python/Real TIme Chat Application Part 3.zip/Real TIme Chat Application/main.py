from flask import Flask, render_template, request, redirect, redirect, url_for
from flask_socketio import SocketIO, join_room, leave_room
from flask_login import LoginManager, login_required, logout_user, login_user, current_user
import json


app = Flask(__name__)
app.secret_key = "some secrete key"
socketio = SocketIO(app)
login_manager = LoginManager()
login_manager.init_app(app)

@app.route("/", methods=["GET", "POST"])
def home():
    return render_template("index.html")
@app.route("/chat", methods=["GET", "POST"])
def chat():
    if request.method == "POST":
        name = request.form.get("name")
        code = request.form.get("roome_code")
    return render_template("chatting.html", code=code, name=name)

@socketio.on('joined_room')
def handle_joined_room(message):
    print(message['name'])
    join_room(message['code'])
    app.logger.info(f"{message['name']} has joined the room {message['code']}")

@socketio.on('send_message')
def handle_send_room(message):
    socketio.emit('recieve_message', message, room=message['code'])
    app.logger.info(f"{message['name']} has sent the message {message['message']}")

@socketio.on('leaved_room')
def handle_leaved_room(message):
    leave_room(message['code'])
    app.logger.info(f"{message['name']} has leave the room {message['code']}")


if __name__ == "__main__":
    socketio.run(app, debug=True)